// LLM Platform Selectors
const LLM_PLATFORMS = {
  'chat.openai.com': {
    inputSelector: 'textarea[data-id="root"]',
    submitSelector: 'button[data-testid="send-button"]'
  },
  'claude.ai': {
    inputSelector: 'div[contenteditable="true"]',
    submitSelector: 'button[aria-label="Send message"]'
  },
  'gemini.google.com': {
    inputSelector: 'textarea[aria-label="Input box"]',
    submitSelector: 'button[aria-label="Send message"]'
  }
};

// Sensitive data patterns
const PATTERNS = {
  ssn: {
    pattern: /\b\d{3}[-.]?\d{2}[-.]?\d{4}\b/g,
    description: 'Social Security Number'
  },
  creditCard: {
    pattern: /\b\d{4}[-.]?\d{4}[-.]?\d{4}[-.]?\d{4}\b/g,
    description: 'Credit Card Number'
  },
  email: {
    pattern: /\b[\w\.-]+@[\w\.-]+\.\w+\b/g,
    description: 'Email Address'
  },
  phone: {
    pattern: /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g,
    description: 'Phone Number'
  },
  medicalRecord: {
    pattern: /\b(MRN|Medical Record Number)[:.]?\s*\d+\b/gi,
    description: 'Medical Record Number'
  },
  dob: {
    pattern: /\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b/g,
    description: 'Date of Birth'
  },
  address: {
    pattern: /\b\d+\s+[\w\s,]+(?:street|st|avenue|ave|road|rd|boulevard|blvd|lane|ln|drive|dr)\b/gi,
    description: 'Physical Address'
  }
};

// Create warning overlay
function createWarningOverlay() {
  const overlay = document.createElement('div');
  overlay.className = 'opaque-ai-warning';
  overlay.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    z-index: 10000;
    max-width: 400px;
    width: 90%;
  `;
  return overlay;
}

// Show warning modal
function showWarningModal(sensitiveParts) {
  const overlay = createWarningOverlay();
  const warnings = Object.entries(sensitiveParts)
    .map(([type, matches]) => `<li>${PATTERNS[type].description} detected</li>`)
    .join('');
    
  overlay.innerHTML = `
    <h3 style="color: #dc2626; margin: 0 0 10px; font-size: 18px;">⚠️ Sensitive Information Detected</h3>
    <p style="margin: 0 0 15px;">The following sensitive information was found in your message:</p>
    <ul style="margin: 0 0 15px; padding-left: 20px;">${warnings}</ul>
    <div style="display: flex; justify-content: flex-end; gap: 10px;">
      <button id="opaque-ai-proceed" style="padding: 8px 16px; background: #dc2626; color: white; border: none; border-radius: 4px; cursor: pointer;">Proceed Anyway</button>
      <button id="opaque-ai-edit" style="padding: 8px 16px; background: #4b5563; color: white; border: none; border-radius: 4px; cursor: pointer;">Edit Message</button>
    </div>
  `;
  
  document.body.appendChild(overlay);
  
  return new Promise((resolve) => {
    document.getElementById('opaque-ai-proceed').onclick = () => {
      overlay.remove();
      resolve(true);
    };
    document.getElementById('opaque-ai-edit').onclick = () => {
      overlay.remove();
      resolve(false);
    };
  });
}

// Check text for sensitive information
function checkSensitiveInfo(text) {
  const sensitiveParts = {};
  for (const [type, { pattern }] of Object.entries(PATTERNS)) {
    const matches = text.match(pattern);
    if (matches) {
      sensitiveParts[type] = matches;
    }
  }
  return Object.keys(sensitiveParts).length > 0 ? sensitiveParts : null;
}

// Monitor specific platform
function monitorPlatform() {
  const hostname = window.location.hostname;
  const platform = LLM_PLATFORMS[hostname];
  
  if (!platform) return;
  
  // Find the input element
  const input = document.querySelector(platform.inputSelector);
  const submitButton = document.querySelector(platform.submitSelector);
  
  if (!input || !submitButton) return;
  
  // Intercept the submit button click
  submitButton.addEventListener('click', async (e) => {
    const text = input.value || input.textContent;
    const sensitiveParts = checkSensitiveInfo(text);
    
    if (sensitiveParts) {
      e.preventDefault();
      e.stopPropagation();
      
      const proceed = await showWarningModal(sensitiveParts);
      if (proceed) {
        // Simulate the original click
        const newEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        submitButton.dispatchEvent(newEvent);
      }
    }
  }, true);
}

// Initialize monitoring
monitorPlatform();

// Add styles
const style = document.createElement('style');
style.textContent = `
  .opaque-ai-warning {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
  }
  .opaque-ai-warning button:hover {
    opacity: 0.9;
  }
`;
document.head.appendChild(style);
